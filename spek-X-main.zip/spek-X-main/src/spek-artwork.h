#pragma once

#define ART_SPEK "art-spek"
#define ART_OPEN "art-open"
#define ART_SAVE "art-save"
#define ART_HELP "art-help"
#define ART_CLOSE "art-close"

void spek_artwork_init();
