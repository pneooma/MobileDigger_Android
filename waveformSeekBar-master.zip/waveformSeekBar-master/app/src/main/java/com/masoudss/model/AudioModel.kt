package com.masoudss.model

data class AudioModel(
    var title: String = "",
    var artist: String = "",
    var path: String = ""
)