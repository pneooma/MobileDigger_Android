package com.masoudss.lib.utils

internal annotation class ThreadBlocking
