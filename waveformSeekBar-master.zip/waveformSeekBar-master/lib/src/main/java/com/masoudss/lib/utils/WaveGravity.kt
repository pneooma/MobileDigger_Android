package com.masoudss.lib.utils

enum class WaveGravity {
    TOP,
    CENTER,
    BOTTOM
}